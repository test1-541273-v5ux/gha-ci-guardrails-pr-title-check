# Changelog

## 0.1.2 - 2026-02-02
- Automated release bundle generated for CI Guardrails - PR Title Check.

## 0.1.1 - 2026-02-02
- Automated release bundle generated for CI Guardrails - PR Title Check.
